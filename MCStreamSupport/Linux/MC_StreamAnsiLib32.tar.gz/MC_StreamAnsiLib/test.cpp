#include <stdlib.h>
#include <stdio.h>

#include "typedefs.h"
#include "MCSAStreamFile.h"
#include "MCSAStream.h"

int main(int argc, char **argv)
{
    if (argc != 2)
	{
		printf("Usage: test mcd-file\n");
		exit(0);
	}

	printf("sizeof(MCSHDR) = %ld\n",sizeof(MCSHDR));

	CMCSAStreamFile* file = new CMCSAStreamFile();
		
	FileOpenResult Res = file->OpenFile(argv[1]);

	if (Res != 0)
	{
		fprintf(stderr,"Error opening file %s\n",argv[1]);
		exit(1);
	}

	for(int i = 0;i < file->GetStreamCount();i++)
	{
		CMCSAStream* stream = file->GetStream(i);
		printf("Stream %d: %s\n",i,stream->GetBufferID());
	}


	file->CloseFile();

	delete file;
}
