Windows:
========

To compile in the command line:

c:\Program Files\Microsoft Visual Studio 10.0\VC\bin\vcvars32.bat
or simular for other versions (same version as we use is recommended, that is 10.0 (2010))

For Windows you need boost 1.44.0
compile it with:
bootstrap.bat
bjam --with-filesystem --with-date_time -d+2 threading=multi --stagedir=.
bjam --with-filesystem --with-date_time -d+2 threading=multi link=static runtime-link=static --stagedir=.
bjam --with-filesystem --with-date_time -d+2 threading=multi --stagedir=./64 address-model=64
bjam --with-filesystem --with-date_time -d+2 threading=multi link=static runtime-link=static --stagedir=./64 address-model=64

cl Demo.cpp /MD /EHsc MC_StreamAnsiLib.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl Demo.cpp /MDd /EHsc MC_StreamAnsiLibd.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl Demo.cpp /MT /EHsc MC_StreamAnsiLibS.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl Demo.cpp /MTd /EHsc MC_StreamAnsiLibSd.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl test.cpp /MD /EHsc MC_StreamAnsiLib.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl test.cpp /MDd /EHsc MC_StreamAnsiLibd.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl test.cpp /MT /EHsc MC_StreamAnsiLibS.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\
cl test.cpp /MTd /EHsc MC_StreamAnsiLibSd.lib /link /LIBPATH:d:\Programming\boost\boost_1_44_0\lib\

In an Environment:

Linker:Input:Additional Dependencies  "MC_StreamAnsiLib.lib, MC_StreamAnsiLibd.lib, MC_StreamAnsiLibS.lib or MC_StreamAnsiLibSd.lib"
c/c++:General:Additional Include Directories "Path where you have the Headerfiles"
c/c++:Code Generation:Runtime Library "Multi-threaded DLL, Multi-threaded Debug DLL, Multi-threaded or Multi-threaded Debug"

Maybe it is easier NOT to use Unicode

Linux:
======

c++ Demo.cpp -o Demo libMCStream.a
c++ -g Demo.cpp -o Demod libMCStreamd.a
c++ -Wl,-R,. Demo.cpp -o Demo_so libMCStream.so
c++ -g -Wl,-R,. Demo.cpp -o Demod_so libMCStreamd.so
c++ test.cpp -o test libMCStream.a
c++ -g test.cpp -o testd libMCStreamd.a
c++ -Wl,-R,. test.cpp -o test_so libMCStream.so
c++ -Wl,-R,. -g test.cpp -o testd_so libMCStreamd.so

MacOSX:
======

c++ Demo.cpp -o Demo libMCStream.a
c++ -g Demo.cpp -o Demod libMCStreamd.a
c++ Demo.cpp -o Demo_so libMCStream.so
c++ -g Demo.cpp -o Demod_so libMCStreamd.so
c++ test.cpp -o test libMCStream.a
c++ -g test.cpp -o testd libMCStreamd.a
c++ test.cpp -o test_so libMCStream.so
c++ -g test.cpp -o testd_so libMCStreamd.so

For each library that a program uses, the dynamic linker looks for it in each directory in DYLD_LIBRARY_PATH in turn. If it still can't find the library, it then  searches DYLD_FALLBACK_FRAME-WORK_PATH and DYLD_FALLBACK_LIBRARY_PATH and . in turn. see man dyld for more details. 
