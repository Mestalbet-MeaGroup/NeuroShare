/*
  
  Demo to read an .mcd file from linux

  (c) 2006 Multi Channel Systems MCS GmbH

  For Documentation see the MC_StreamTest Project for Windows

  The OLE functions must be replaced by ANSI functions with the same name

 */

#include <stdio.h>
#include <stdlib.h>

#include <iostream>
#include <string>


#include "typedefs.h"

#include "MCSAChannel.h"
#include "MCSAChunk.h"
#include "MCSAEvent.h"
#include "MCSAEvtParam.h"
#include "MCSAEvtRaw.h"
#include "MCSAEvtSpike.h"
#include "MCSAEvtTrigger.h"
#include "MCSAInfoFilter.h"
#include "MCSAInfoParam.h"
#include "MCSAInfoSpike.h"
#include "MCSAInfoTrigger.h"
#include "MCSAStream.h"
#include "MCSAStreamFile.h"
#include "MCSATimeStamp.h"
#include "MCSAStream.h"

void print_start_stop_time(CMCSATimeStamp* StartTime, CMCSATimeStamp* StopTime);
void ReadRawData(CMCSAStream* Stream, CMCSATimeStamp* ReadStartTime, CMCSATimeStamp* ReadStopTime);
void ReadDigitalData(CMCSAStream* Stream, CMCSATimeStamp* ReadStartTime, CMCSATimeStamp* ReadStopTime);



int main(int argc, char **argv)
{
  CMCSAStreamFile	m_MCSFile;			
  
  if (argc != 2)
  {
	  printf("Usage: test mcd-file\n");
	  exit(0);
  }
  std::string csFileName(argv[1]);


  cout << "Welcome to MCStream Demo" << endl;
  
  //	m_MCSFile.CreateDispatch("mcstream.mcsstrm");
  short sFileOpenResult = m_MCSFile.OpenFile(csFileName.c_str());
  
  if(sFileOpenResult != 0)
  {
    std::string s;
    s = "Error loading file: ";
    s += csFileName;
    s += "\n\n";
      
    switch(sFileOpenResult)
    {
      case 0: break;
      case 1: s += "File can not be opened.";
	  break;
      case 2: s += "Wrong file format.";
    break;
      case 3: s += "Wrong file header.";
	  break;
      case 4: s += "Empty data file.";
	  break;
      default: 
	  break;
    }
    cout << s << endl;
  }

  CMCSATimeStamp* StartTime = m_MCSFile.GetStartTime();
  CMCSATimeStamp* StopTime = m_MCSFile.GetStopTime();

  print_start_stop_time(StartTime, StopTime);

  
  long lStreamCount = m_MCSFile.GetStreamCount();
  cout << "This File contains " << lStreamCount << " streams" << endl;
  
  for (int i = 0; i < lStreamCount; i++) {
    CMCSAStream* Stream = m_MCSFile.GetStream(i);
    std::string BufferName = Stream->GetBufferID();
    cout << endl;
    cout << "Stream: " << i << " BufferId: " << BufferName;
    cout << " Channels in stream: " << Stream->GetChannelCount();
    cout << endl;

    CMCSATimeStamp ReadStartTime = *StartTime;
    CMCSATimeStamp ReadStopTime = *StartTime;
    
    // read first 100 ms of data from stream
    ReadStartTime.SetNanosecondFromStart(0);
    ReadStartTime.SetMicrosecondFromStart(0);
    ReadStartTime.SetMillisecondFromStart(0);
    ReadStartTime.SetSecondFromStart(0);

    ReadStopTime.SetNanosecondFromStart(0);
    ReadStopTime.SetMicrosecondFromStart(0);
    ReadStopTime.SetMillisecondFromStart(100);
    ReadStopTime.SetSecondFromStart(0);

    if (BufferName.find("digi") != -1 || 
        BufferName.find("filt") != -1)
    {
      ReadDigitalData(Stream, &ReadStartTime, &ReadStopTime);
    }
    else if (BufferName.find("elec") != -1 || 
             BufferName.find("anlg") != -1)
    {
      ReadRawData(Stream, &ReadStartTime, &ReadStopTime);
    }
    else 
    {
      cout << "not supported by this demo yet" << endl;
    }
    
    
  }
  m_MCSFile.CloseFile();
}


void ReadRawData(CMCSAStream* Stream, CMCSATimeStamp* ReadStartTime, CMCSATimeStamp* ReadStopTime)
{
    long eventCount[128];
    eventCount[0] = 0;
    Stream->EventCountFromTo(ReadStartTime, ReadStopTime, eventCount);
    
    long bufferSize = Stream->GetRawDataBufferSize(ReadStartTime, ReadStopTime);
    cout << "Events in first 100 ms: " << eventCount[0];
    cout << " Buffer size: " << bufferSize << endl;
    
    short* pBuffer = new short[bufferSize];
    long rawDataCount = Stream->GetRawData(pBuffer, bufferSize, ReadStartTime, ReadStopTime);
    int ADZero = Stream->GetADZero();
    double UnitsPerAD = Stream->GetUnitsPerAD();
    int ADBits = Stream->GetADBits();
    
    cout << "unitsPerAd: " << UnitsPerAD << endl;
    cout << "Voltage Range: -" << UnitsPerAD*(1<<(ADBits-1)) << "V .. " << UnitsPerAD*(1<<(ADBits-1)) << "V" << endl;
    
    int ChannelsInStream = Stream->GetChannelCount();
    for (int channel = 0; channel < ChannelsInStream; channel++)
    {
      CMCSAChannel* Channel = Stream->GetChannel(channel);
      std::string channelName = Channel->GetDecoratedName();
      cout << "Channel " << channelName << " ";
      for (int sample = 0; sample < 15; sample++)
      {
        double realWordValue = (((unsigned short)pBuffer[(sample*ChannelsInStream)+channel]) - ADZero) * UnitsPerAD;
        cout << " " << realWordValue;
      }
      cout << endl;
    }
    
    delete pBuffer;
//    delete eventCount;
}

void ReadDigitalData(CMCSAStream* Stream, CMCSATimeStamp* ReadStartTime, CMCSATimeStamp* ReadStopTime)
{
    long eventCount[128];
    eventCount[0] = 0;
    Stream->EventCountFromTo(ReadStartTime, ReadStopTime, eventCount);
    
    long bufferSize = Stream->GetRawDataBufferSize(ReadStartTime, ReadStopTime);
    cout << "Events in first 100 ms: " << eventCount[0];
    cout << " Buffer size: " << bufferSize << endl;
    
    short* pBuffer = new short[bufferSize];
    long rawDataCount = Stream->GetRawData(pBuffer, bufferSize, ReadStartTime, ReadStopTime);
    
    
    int ChannelsInStream = Stream->GetChannelCount();
    for (int channel = 0; channel < ChannelsInStream; channel++)
    {
      CMCSAChannel* Channel = Stream->GetChannel(channel);
      std::string channelName = Channel->GetDecoratedName();
      cout << "Channel " << channelName << " ";
      for (int sample = 0; sample < 15; sample++)
      {
        unsigned short digital = (((unsigned short)pBuffer[(sample*ChannelsInStream)+channel]));
        cout << " 0x" << hex << digital << dec;
      }
      cout << endl;
    }
    
    delete pBuffer;
}

void print_start_stop_time(CMCSATimeStamp* StartTime, CMCSATimeStamp* StopTime)
{
  int iSeconds = StopTime->GetSecondFromStart();
  int iMilliS = StopTime->GetMillisecondFromStart();
  int iMicroS = StopTime->GetMicrosecondFromStart();
  int iNanoS = StopTime->GetNanosecondFromStart();
  
  cout << "Start Time: " << StartTime->GetDay() << "." << StartTime->GetMonth() << "." << StartTime->GetYear() 
       << "   " << StartTime->GetHour() << ":" << StartTime->GetMinute() << ":" << StartTime->GetSecond() << endl;
  cout << "Stop  Time: " << StopTime->GetDay() << "." << StopTime->GetMonth() << "." << StopTime->GetYear() 
       << "   " << StopTime->GetHour() << ":" << StopTime->GetMinute() << ":" << StopTime->GetSecond() << endl;
  
  cout << "Length of file: " << iSeconds << "." << iMilliS  << " s" << endl;
}
